<?php if (isset($component)) { $__componentOriginal9254814399987dd9cea73cc357b3caf2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9254814399987dd9cea73cc357b3caf2 = $attributes; } ?>
<?php $component = App\View\Components\TenantAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tenant-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TenantAppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Users')); ?>

            <?php if (isset($component)) { $__componentOriginalcad79c981796ff357c26f887b39870de = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcad79c981796ff357c26f887b39870de = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.btn-link','data' => ['class' => 'ml-4 float-right','href' => ''.e(route('users.create')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ml-4 float-right','href' => ''.e(route('users.create')).'']); ?>Add User <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcad79c981796ff357c26f887b39870de)): ?>
<?php $attributes = $__attributesOriginalcad79c981796ff357c26f887b39870de; ?>
<?php unset($__attributesOriginalcad79c981796ff357c26f887b39870de); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcad79c981796ff357c26f887b39870de)): ?>
<?php $component = $__componentOriginalcad79c981796ff357c26f887b39870de; ?>
<?php unset($__componentOriginalcad79c981796ff357c26f887b39870de); ?>
<?php endif; ?>
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">


                    <div class="relative overflow-x-auto">
                        <table class="w-full text-sm text-left text-gray-500">
                            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-6 py-3">
                                        Name
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        Email
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        Role
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        Action
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="bg-white border-b">
                                        <th scope="row"
                                            class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap
                                        Apple MacBook Pro 17"><?php echo e($user->name); ?>

                                            </th>
                                        <td class="px-6 py-4">
                                            <?php echo e($user->email); ?>

                                        </td>
                                        <td class="px-6 py-4">
                                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($role->name); ?><?php echo e($loop->last ? "" : ","); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td class="px-6 py-4">
                                            <?php if (isset($component)) { $__componentOriginalcad79c981796ff357c26f887b39870de = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcad79c981796ff357c26f887b39870de = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.btn-link','data' => ['href' => ''.e(route('users.edit', $user->id)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('users.edit', $user->id)).'']); ?>Edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcad79c981796ff357c26f887b39870de)): ?>
<?php $attributes = $__attributesOriginalcad79c981796ff357c26f887b39870de; ?>
<?php unset($__attributesOriginalcad79c981796ff357c26f887b39870de); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcad79c981796ff357c26f887b39870de)): ?>
<?php $component = $__componentOriginalcad79c981796ff357c26f887b39870de; ?>
<?php unset($__componentOriginalcad79c981796ff357c26f887b39870de); ?>
<?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>

                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9254814399987dd9cea73cc357b3caf2)): ?>
<?php $attributes = $__attributesOriginal9254814399987dd9cea73cc357b3caf2; ?>
<?php unset($__attributesOriginal9254814399987dd9cea73cc357b3caf2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9254814399987dd9cea73cc357b3caf2)): ?>
<?php $component = $__componentOriginal9254814399987dd9cea73cc357b3caf2; ?>
<?php unset($__componentOriginal9254814399987dd9cea73cc357b3caf2); ?>
<?php endif; ?>
<?php /**PATH /home/juanpab1o/Escritorio/Laravel-Multi-Tenant-main/resources/views/app/users/index.blade.php ENDPATH**/ ?>